local drop_words =
{ "示~例~", "肏女人", }
return drop_words